extends Node2D

# RED ALERT MOBILE — Phase 1 playable RTS foundation.
# Original placeholder art; no EA/Westwood assets are included.

const WORLD := Vector2(1900, 1180)
const SPEED := 155.0
const TANK_COST := 150
const INFANTRY_COST := 75
const ATTACK_RANGE := 175.0

var units: Array[Dictionary] = []
var selected_ids: Array[int] = []
var next_id := 1
var credits := 650
var player_base_hp := 1000.0
var enemy_base_hp := 1000.0
var enemy_spawn_clock := 0.0
var camera := Vector2.ZERO
var message := "Select a BLUE unit, then tap the ground to move."
var message_left := 6.0
var last_view := Vector2(1280, 720)

var btn_tank := Rect2(16, 16, 150, 54)
var btn_infantry := Rect2(176, 16, 170, 54)
var btn_reset := Rect2(356, 16, 110, 54)

func _ready() -> void:
    _spawn(Vector2(350, 490), true, "tank")
    _spawn(Vector2(430, 550), true, "tank")
    _spawn(Vector2(350, 610), true, "infantry")
    _spawn(Vector2(1530, 470), false, "tank")
    _spawn(Vector2(1600, 560), false, "infantry")
    _set_message("RED ALERT MOBILE — Phase 1: move, fight, and produce units.", 7)

func _spawn(pos: Vector2, friendly: bool, kind: String) -> void:
    units.append({
        "id": next_id, "pos": pos, "target": pos, "friendly": friendly,
        "kind": kind, "hp": 100.0 if kind == "tank" else 65.0,
        "max_hp": 100.0 if kind == "tank" else 65.0,
        "cooldown": randf_range(0.0, 0.6), "attack_target": -1
    })
    next_id += 1

func _process(delta: float) -> void:
    enemy_spawn_clock += delta
    message_left = maxf(0.0, message_left - delta)
    if enemy_spawn_clock >= 16.0 and units.size() < 35:
        enemy_spawn_clock = 0.0
        _spawn(Vector2(1580, randf_range(300, 850)), false, "tank")
        _set_message("Enemy reinforcements detected!", 2.5)

    for i in range(units.size()):
        var u: Dictionary = units[i]
        u.cooldown = maxf(0.0, float(u.cooldown) - delta)
        var target_index := _nearest_enemy(i)
        if target_index >= 0:
            var enemy: Dictionary = units[target_index]
            var distance: float = u.pos.distance_to(enemy.pos)
            if distance <= ATTACK_RANGE:
                u.target = u.pos
                if u.cooldown <= 0.0:
                    enemy.hp = float(enemy.hp) - (18.0 if u.kind == "tank" else 9.0)
                    u.cooldown = 0.85 if u.kind == "tank" else 1.1
            elif u.friendly and selected_ids.has(int(u.id)):
                pass
            elif not u.friendly:
                u.target = enemy.pos
        var p: Vector2 = u.pos
        var dest: Vector2 = u.target
        if p.distance_to(dest) > 3.0:
            u.pos = p.move_toward(dest, SPEED * (1.0 if u.kind == "tank" else 1.25) * delta)

    for i in range(units.size() - 1, -1, -1):
        if float(units[i].hp) <= 0.0:
            selected_ids.erase(int(units[i].id))
            units.remove_at(i)

    queue_redraw()

func _nearest_enemy(index: int) -> int:
    var own: Dictionary = units[index]
    var best := -1
    var best_dist := 999999.0
    for j in range(units.size()):
        if j == index or units[j].friendly == own.friendly:
            continue
        var d: float = own.pos.distance_to(units[j].pos)
        if d < best_dist:
            best_dist = d
            best = j
    return best

func _screen_to_world(p: Vector2) -> Vector2:
    return p + camera

func _world_to_screen(p: Vector2) -> Vector2:
    return p - camera

func _input(event: InputEvent) -> void:
    if event is InputEventScreenTouch and event.pressed:
        _tap(event.position)
    elif event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
        _tap(event.position)
    elif event is InputEventScreenDrag:
        if event.position.y > 82:
            camera -= event.relative
            _clamp_camera()
    elif event is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_MIDDLE):
        camera -= event.relative
        _clamp_camera()

func _clamp_camera() -> void:
    var view := get_viewport_rect().size
    camera.x = clampf(camera.x, 0, maxf(0, WORLD.x - view.x))
    camera.y = clampf(camera.y, 0, maxf(0, WORLD.y - view.y))

func _tap(p: Vector2) -> void:
    if btn_tank.has_point(p):
        _produce("tank")
        return
    if btn_infantry.has_point(p):
        _produce("infantry")
        return
    if btn_reset.has_point(p):
        get_tree().reload_current_scene()
        return

    var wp := _screen_to_world(p)
    for i in range(units.size() - 1, -1, -1):
        var u: Dictionary = units[i]
        if u.friendly and wp.distance_to(u.pos) <= 34:
            var id := int(u.id)
            if not Input.is_key_pressed(KEY_SHIFT):
                selected_ids.clear()
            if selected_ids.has(id):
                selected_ids.erase(id)
            else:
                selected_ids.append(id)
            _set_message("%d friendly unit(s) selected. Tap ground to move." % selected_ids.size(), 3)
            return

    if selected_ids.size() > 0:
        var destinations := selected_ids.size()
        var slot := 0
        for u in units:
            if selected_ids.has(int(u.id)):
                var angle := TAU * float(slot) / float(destinations)
                u.target = Vector2(
                    clampf(wp.x + cos(angle) * 34.0, 30, WORLD.x - 30),
                    clampf(wp.y + sin(angle) * 34.0, 125, WORLD.y - 30)
                )
                slot += 1
        _set_message("Move order issued.", 1.8)
    else:
        selected_ids.clear()

func _produce(kind: String) -> void:
    var cost := TANK_COST if kind == "tank" else INFANTRY_COST
    if credits < cost:
        _set_message("Not enough credits.", 2)
        return
    credits -= cost
    _spawn(Vector2(315 + randf_range(-22, 22), 690 + randf_range(-22, 22)), true, kind)
    _set_message("%s produced. -%d credits." % [kind.capitalize(), cost], 2)

func _set_message(value: String, duration: float) -> void:
    message = value
    message_left = duration

func _draw() -> void:
    var view := get_viewport_rect().size
    draw_rect(Rect2(Vector2.ZERO, view), Color(0.09, 0.16, 0.12))
    # terrain grid
    for x in range(0, int(WORLD.x), 100):
        draw_line(_world_to_screen(Vector2(x, 0)), _world_to_screen(Vector2(x, WORLD.y)), Color(0.25, 0.34, 0.26, 0.35), 1)
    for y in range(0, int(WORLD.y), 100):
        draw_line(_world_to_screen(Vector2(0, y)), _world_to_screen(Vector2(WORLD.x, y)), Color(0.25, 0.34, 0.26, 0.35), 1)

    # simple terrain features
    for k in range(8):
        var tree := _world_to_screen(Vector2(610 + k * 85, 240 + (k % 3) * 230))
        draw_circle(tree, 22, Color(0.12, 0.29, 0.17))
        draw_circle(tree + Vector2(-5, -6), 13, Color(0.18, 0.39, 0.21))

    _draw_base(Vector2(190, 390), true)
    _draw_base(Vector2(1510, 390), false)

    for u in units:
        _draw_unit(u)

    # HUD
    draw_rect(Rect2(0, 0, view.x, 82), Color(0.035, 0.055, 0.05, 0.96))
    _button(btn_tank, "BUILD TANK\n$150")
    _button(btn_infantry, "BUILD INFANTRY\n$75")
    _button(btn_reset, "RESTART")
    var font := ThemeDB.fallback_font
    draw_string(font, Vector2(maxf(490, view.x - 260), 35), "CREDITS: $%d" % credits, HORIZONTAL_ALIGNMENT_LEFT, -1, 22, Color(0.95, 0.86, 0.45))
    draw_string(font, Vector2(18, view.y - 18), "RED ALERT MOBILE  |  PHASE 1 PROTOTYPE", HORIZONTAL_ALIGNMENT_LEFT, -1, 14, Color(0.75, 0.82, 0.75))
    if message_left > 0:
        draw_rect(Rect2(0, 86, view.x, 34), Color(0.02, 0.03, 0.025, 0.82))
        draw_string(font, Vector2(18, 109), message, HORIZONTAL_ALIGNMENT_LEFT, -1, 17, Color.WHITE)

func _draw_base(pos: Vector2, friendly: bool) -> void:
    var p := _world_to_screen(pos)
    var c := Color(0.12, 0.42, 0.62) if friendly else Color(0.62, 0.20, 0.15)
    draw_rect(Rect2(p, Vector2(170, 170)), c)
    draw_rect(Rect2(p + Vector2(12, 12), Vector2(146, 146)), c.lightened(0.18), false, 4)
    draw_string(ThemeDB.fallback_font, p + Vector2(8, -8), "ALLIED HQ" if friendly else "ENEMY HQ", HORIZONTAL_ALIGNMENT_LEFT, -1, 18, Color.WHITE)
    var hp := player_base_hp if friendly else enemy_base_hp
    draw_rect(Rect2(p + Vector2(8, 178), Vector2(154, 9)), Color(0.12, 0.08, 0.07))
    draw_rect(Rect2(p + Vector2(8, 178), Vector2(154.0 * hp / 1000.0, 9)), Color(0.25, 0.85, 0.35))

func _draw_unit(u: Dictionary) -> void:
    var p: Vector2 = _world_to_screen(u.pos)
    var friendly: bool = u.friendly
    var body := Color(0.18, 0.72, 0.92) if friendly else Color(0.91, 0.25, 0.18)
    if selected_ids.has(int(u.id)):
        draw_arc(p, 25, 0, TAU, 32, Color(1.0, 0.9, 0.25), 3)
    if u.kind == "tank":
        draw_rect(Rect2(p - Vector2(19, 12), Vector2(38, 24)), body.darkened(0.18))
        draw_rect(Rect2(p - Vector2(11, 9), Vector2(23, 18)), body)
        draw_line(p, p + Vector2(25, -2), Color(0.82, 0.85, 0.78), 5)
    else:
        draw_circle(p, 11, body)
        draw_circle(p + Vector2(0, -3), 4, Color(0.9, 0.83, 0.68))
    var bar_w := 38.0
    draw_rect(Rect2(p + Vector2(-bar_w/2, 20), Vector2(bar_w, 4)), Color(0.16, 0.08, 0.07))
    draw_rect(Rect2(p + Vector2(-bar_w/2, 20), Vector2(bar_w * maxf(0, u.hp) / u.max_hp, 4)), Color(0.25, 0.9, 0.32))

func _button(r: Rect2, label: String) -> void:
    draw_rect(r, Color(0.13, 0.24, 0.22))
    draw_rect(r, Color(0.45, 0.62, 0.54), false, 2)
    var lines := label.split("\n")
    var font := ThemeDB.fallback_font
    if lines.size() == 1:
        draw_string(font, r.position + Vector2(10, 34), label, HORIZONTAL_ALIGNMENT_LEFT, -1, 17, Color.WHITE)
    else:
        draw_string(font, r.position + Vector2(10, 22), lines[0], HORIZONTAL_ALIGNMENT_LEFT, -1, 15, Color.WHITE)
        draw_string(font, r.position + Vector2(10, 42), lines[1], HORIZONTAL_ALIGNMENT_LEFT, -1, 14, Color(0.95, 0.86, 0.45))
