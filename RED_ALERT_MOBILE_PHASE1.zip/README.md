# RED ALERT MOBILE — Phase 1

This is the first playable **2D RTS prototype**, not a complete Red Alert game and not an APK yet.

## Included
- Godot 4.2+ project.
- Touch and mouse selection.
- Move orders for selected units.
- Tank and infantry production using credits.
- Basic enemy unit spawning and automatic combat.
- Simple battlefield, bases, health bars, and HUD.
- Original placeholder vector-style graphics.

## Not included yet
Campaigns, finished factions, real building placement, pathfinding, advanced AI, multiplayer/server, sound, final art, localization, save system, and Google Play release packaging.

## Run
1. Install Godot 4.2 or newer.
2. Import `project.godot`.
3. Press F6/F5 to run the project.
4. On a touch device: tap a blue unit, then tap the ground to move. Use the production buttons at the top.

## Android export
A release APK/AAB requires Godot Android export templates, Android SDK/JDK setup, signing credentials, device testing, and store compliance. This source archive does not contain a prebuilt APK.

All art and code in this prototype are original placeholders. It does not include EA/Westwood game assets.
