# RED ALERT MOBILE — Prototype V2

An original, asset-free top-down RTS prototype built with Godot 4.

## Current playable features
- Top-down tile battlefield
- Player and AI bases
- Select friendly units by touch/click and issue move orders
- Tank, infantry, rocket, IFV and harvester unit types
- Purchase units and a barracks using credits
- Basic automatic combat and enemy reinforcements
- Victory/defeat when a command building is destroyed

## Important limitations
This is a playable prototype, not the complete requested game and not an APK.
Online multiplayer, campaigns, naval/air units, save/load, full pathfinding,
production queues, polished original art/audio, localization, and Android
export/signing are not implemented yet.

## Open
Install Godot 4.2 or newer, import this folder as a project, then run.
All art is drawn in code; no EA/Westwood assets are included.
