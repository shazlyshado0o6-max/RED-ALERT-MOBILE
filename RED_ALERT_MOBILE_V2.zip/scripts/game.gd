extends Node2D

const TILE := 48
const MAP_W := 32
const MAP_H := 22
const PLAYER := 0
const ENEMY := 1

var credits := 1500
var enemy_credits := 1500
var selected: Array = []
var units: Array[Dictionary] = []
var buildings: Array[Dictionary] = []
var bullets: Array[Dictionary] = []
var tick := 0.0
var spawn_timer := 0.0
var message := "Build a base. Select units, then tap a destination."
var drag_start := Vector2.ZERO
var dragging := false
var camera_offset := Vector2.ZERO
var game_over := false

func _ready() -> void:
    randomize()
    _make_building(Vector2(4, 5), PLAYER, "Command")
    _make_building(Vector2(24, 14), ENEMY, "Command")
    _make_building(Vector2(7, 5), PLAYER, "Barracks")
    _make_building(Vector2(21, 14), ENEMY, "Barracks")
    for i in range(3):
        _make_unit(Vector2(6 + i, 8), PLAYER, "Tank")
    for i in range(3):
        _make_unit(Vector2(23 + i, 11), ENEMY, "Tank")
    set_process(true)

func _make_building(tile: Vector2, team: int, kind: String) -> void:
    buildings.append({"tile":tile, "team":team, "kind":kind, "hp":500 if kind=="Command" else 300})

func _make_unit(tile: Vector2, team: int, kind: String) -> void:
    var stats = {"Tank":[180,42,95.0,100], "Infantry":[75,16,125.0,50], "Rocket":[65,32,145.0,75], "Harvester":[220,0,75.0,125], "IFV":[130,28,125.0,90]}
    var s: Array = stats.get(kind, stats["Tank"])
    units.append({"pos":(tile+Vector2(0.5,0.5))*TILE, "team":team, "kind":kind, "hp":s[0], "maxhp":s[0], "damage":s[1], "range":s[2], "speed":s[3], "target":Vector2(-1,-1), "cool":0.0})

func _process(delta: float) -> void:
    if game_over: queue_redraw(); return
    tick += delta
    spawn_timer += delta
    if spawn_timer > 14.0:
        spawn_timer = 0
        if enemy_credits >= 100:
            _make_unit(Vector2(24+randi_range(-2,2), 12+randi_range(-1,2)), ENEMY, "Tank")
            enemy_credits -= 100
    _update_units(delta)
    _update_bullets(delta)
    _remove_dead()
    queue_redraw()

func _update_units(delta: float) -> void:
    for u in units:
        u.cool = maxf(0.0, u.cool-delta)
        var enemy = _nearest_enemy(u)
        if enemy != null and u.pos.distance_to(enemy.pos) <= u.range:
            if u.cool <= 0 and u.damage > 0:
                bullets.append({"pos":u.pos, "target":enemy, "damage":u.damage, "team":u.team, "speed":360.0})
                u.cool = 0.9 if u.kind=="Tank" else 1.2
        elif u.target != Vector2(-1,-1):
            var d: Vector2 = u.target-u.pos
            if d.length() < 7: u.target = Vector2(-1,-1)
            else: u.pos += d.normalized()*u.speed*delta

func _nearest_enemy(u: Dictionary):
    var best = null
    var dist = 1.0e9
    for e in units:
        if e.team != u.team:
            var d: float = u.pos.distance_to(e.pos)
            if d < dist: dist=d; best=e
    for b in buildings:
        if b.team != u.team:
            var p: Vector2 = (b.tile+Vector2(0.5,0.5))*TILE
            var d: float = u.pos.distance_to(p)
            if d < dist: dist=d; best={"pos":p, "hp":b.hp, "building":b}
    return best

func _update_bullets(delta: float) -> void:
    for bullet in bullets:
        var target = bullet.target
        if target == null: continue
        var p: Vector2 = target.pos
        var d: Vector2 = p-bullet.pos
        if d.length() < 12:
            if target.has("building"):
                target.building.hp -= bullet.damage
            else:
                target.hp -= bullet.damage
            bullet.target = null
        else:
            bullet.pos += d.normalized()*bullet.speed*delta

func _remove_dead() -> void:
    for i in range(units.size()-1, -1, -1):
        if units[i].hp <= 0:
            units.remove_at(i)
    for i in range(buildings.size()-1, -1, -1):
        if buildings[i].hp <= 0:
            if buildings[i].kind == "Command":
                game_over = true
                message = "DEFEAT" if buildings[i].team == PLAYER else "VICTORY!"
            buildings.remove_at(i)
    bullets = bullets.filter(func(b): return b.target != null)

func _draw() -> void:
    draw_rect(Rect2(Vector2.ZERO, Vector2(MAP_W*TILE, MAP_H*TILE)), Color("#263c2b"))
    for x in range(MAP_W):
        for y in range(MAP_H):
            var p=Vector2(x*TILE,y*TILE)
            var c=Color("#304a34") if (x+y)%2==0 else Color("#2b4230")
            draw_rect(Rect2(p,Vector2(TILE-1,TILE-1)),c)
    for i in range(12):
        var p=Vector2((i*97%MAP_W)*TILE+8,(i*53%MAP_H)*TILE+8)
        draw_circle(p, 7, Color("#586b48"))
    for b in buildings:
        var p=(b.tile+Vector2(0.5,0.5))*TILE
        var col=Color("#4b91d1") if b.team==PLAYER else Color("#c94c4c")
        draw_rect(Rect2(p-Vector2(20,18),Vector2(40,36)),col)
        draw_rect(Rect2(p-Vector2(14,12),Vector2(28,24)),Color("#202a32"))
        draw_string(ThemeDB.fallback_font, p+Vector2(-23,31), b.kind, HORIZONTAL_ALIGNMENT_LEFT, -1, 10, Color.WHITE)
        _health_bar(p+Vector2(-20,22), b.hp, 500)
    for u in units:
        var col=Color("#64b5f6") if u.team==PLAYER else Color("#ff6666")
        if u.kind=="Infantry" or u.kind=="Rocket":
            draw_circle(u.pos,8,col)
        else:
            draw_rect(Rect2(u.pos-Vector2(13,9),Vector2(26,18)),col)
            draw_rect(Rect2(u.pos-Vector2(4,3),Vector2(18,6)),Color("#20252a"))
        if selected.has(u): draw_arc(u.pos,17,0,TAU,32,Color.YELLOW,2)
        _health_bar(u.pos+Vector2(-13,13),u.hp,u.maxhp)
    for b in bullets:
        draw_circle(b.pos,3,Color("#ffd34e"))
    _draw_ui()

func _health_bar(p: Vector2, hp: float, maxhp: float) -> void:
    draw_rect(Rect2(p,Vector2(28,4)),Color("#222222"))
    draw_rect(Rect2(p,Vector2(28*clampf(hp/maxhp,0,1),4)),Color("#70dc75"))

func _draw_ui() -> void:
    draw_rect(Rect2(0,0,960,42),Color("#101820"))
    draw_string(ThemeDB.fallback_font,Vector2(14,27),"RED ALERT MOBILE   |   CREDITS: %d" % credits,HORIZONTAL_ALIGNMENT_LEFT,-1,18,Color.WHITE)
    draw_string(ThemeDB.fallback_font,Vector2(500,27),message,HORIZONTAL_ALIGNMENT_LEFT,440,14,Color("#f5d98a"))
    var buttons=[["TANK",100],["INF",50],["ROCKET",75],["IFV",90],["HARV",125],["BARRACKS",300]]
    for i in range(buttons.size()):
        var x=12+i*105
        draw_rect(Rect2(x,490,98,42),Color("#172735"))
        draw_rect(Rect2(x,490,98,42),Color("#78a8c9"),false,2)
        draw_string(ThemeDB.fallback_font,Vector2(x+8,516),buttons[i][0],HORIZONTAL_ALIGNMENT_LEFT,-1,14,Color.WHITE)

func _input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed: _tap(event.position)
    elif event is InputEventMouseButton and event.pressed:
        _tap(event.position)
    elif event is InputEventKey and event.pressed and event.keycode==KEY_ESCAPE:
        selected.clear()

func _tap(p: Vector2) -> void:
    if p.y >= 485:
        var idx=int((p.x-12)/105)
        var costs=[100,50,75,90,125,300]
        var kinds=["Tank","Infantry","Rocket","IFV","Harvester","Barracks"]
        if idx>=0 and idx<kinds.size():
            if credits>=costs[idx]:
                credits-=costs[idx]
                if idx==5: _make_building(Vector2(5+randi_range(0,3),10),PLAYER,"Barracks")
                else: _make_unit(Vector2(6,9),PLAYER,kinds[idx])
                message=kinds[idx]+" deployed"
            else: message="Not enough credits"
        return
    var found=null
    for u in units:
        if u.team==PLAYER and u.pos.distance_to(p)<22: found=u; break
    if found!=null:
        if not selected.has(found): selected=[found]
        message=found.kind+" selected"
    elif not selected.is_empty():
        for u in selected: u.target=p
        message="Move order issued"
        selected.clear()
